python3 /autograder/submission/hierarchical.py
