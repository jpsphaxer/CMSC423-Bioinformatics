#!/bin/bash

python3 /autograder/submission/count.py