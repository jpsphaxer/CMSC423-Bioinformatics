#!/bin/bash

python3 /autograder/submission/skew.py