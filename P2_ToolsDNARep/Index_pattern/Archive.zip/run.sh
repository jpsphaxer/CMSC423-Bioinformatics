#!/bin/bash

python3 /autograder/submission/index.py